-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: k7a606.p.ssafy.io    Database: cseon
-- ------------------------------------------------------
-- Server version	8.0.31-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `question_label`
--

DROP TABLE IF EXISTS `question_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `question_label` (
  `question_label_id` bigint NOT NULL AUTO_INCREMENT,
  `label_id` bigint DEFAULT NULL,
  `question_id` bigint DEFAULT NULL,
  PRIMARY KEY (`question_label_id`),
  KEY `FKo9tpr22shijfi4x3oiusf46oc` (`label_id`),
  KEY `FK1gwik15vy68t6g93wbvpaatsm` (`question_id`),
  CONSTRAINT `FK1gwik15vy68t6g93wbvpaatsm` FOREIGN KEY (`question_id`) REFERENCES `question` (`question_id`),
  CONSTRAINT `FKo9tpr22shijfi4x3oiusf46oc` FOREIGN KEY (`label_id`) REFERENCES `label` (`label_id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question_label`
--

LOCK TABLES `question_label` WRITE;
/*!40000 ALTER TABLE `question_label` DISABLE KEYS */;
INSERT INTO `question_label` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,4,6),(7,4,7),(8,2,8),(9,2,9),(10,1,9),(11,2,10),(12,1,10),(13,2,11),(14,4,12),(15,6,12),(16,4,13),(17,6,14),(18,1,15),(19,2,16),(20,6,17),(21,1,18),(22,3,19),(23,1,20),(24,2,21),(25,2,22),(26,1,23),(27,3,24),(28,4,25),(29,3,26),(30,1,27),(31,3,27),(32,2,28),(33,4,29),(34,3,30),(35,4,31),(36,4,32),(37,2,33),(38,4,34),(39,3,35),(40,1,36),(41,3,36),(42,4,37),(43,1,38),(44,6,39),(45,4,40),(46,6,41),(47,4,42),(48,4,43),(49,4,44),(50,4,45),(51,4,46),(52,4,47),(53,4,48),(54,4,49),(55,2,50),(56,4,51),(57,4,52),(58,6,53),(59,2,53),(60,4,54),(61,4,55),(62,1,56),(63,1,57),(64,1,58),(65,1,59),(66,1,60),(67,6,61),(68,1,62),(69,1,63),(70,1,64),(71,5,65),(72,4,66),(73,4,67),(74,1,68),(75,3,69),(76,6,70),(77,8,71),(78,7,72),(79,5,73),(80,5,74),(81,5,75),(82,5,76),(83,5,77),(84,1,78);
/*!40000 ALTER TABLE `question_label` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-20 22:20:35
